"""
TinyGenie — model, training, and generation in one file.

Usage:
    python tinygenie.py train
    python tinygenie.py chat
    python tinygenie.py generate "some prompt"

Output is ONE file: tinygenie.pt — model weights + architecture config +
full tokenizer (vocab+merges) bundled together. Nothing else is needed to
load and talk to the model; your own loader just needs this one file.
"""
import os
import sys
import json
import math
import time

import numpy as np
import torch
import torch.nn as nn
from torch.nn import functional as F
from tokenizers import ByteLevelBPETokenizer


# ---------------- config ----------------
class GPTConfig:
    vocab_size = 32000
    block_size = 256
    n_layer = 6
    n_head = 6
    n_embd = 384
    dropout = 0.1
    bias = False


class TrainConfig:
    batch_size = 8
    grad_accum_steps = 4
    max_iters = 5000
    eval_interval = 250
    eval_iters = 50
    lr = 3e-4
    min_lr = 3e-5
    warmup_iters = 100
    weight_decay = 0.1
    grad_clip = 1.0
    device = "cuda" if torch.cuda.is_available() else "cpu"
    amp = True
    out_path = "tinygenie.pt"          # the one big fat file
    data_path = "data/combined.txt"
    bin_dir = "data"
    tokenizer_dir = "tokenizer"


# ---------------- model ----------------
class CausalSelfAttention(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        assert cfg.n_embd % cfg.n_head == 0
        self.qkv = nn.Linear(cfg.n_embd, 3 * cfg.n_embd, bias=cfg.bias)
        self.proj = nn.Linear(cfg.n_embd, cfg.n_embd, bias=cfg.bias)
        self.attn_drop_p = cfg.dropout
        self.resid_drop = nn.Dropout(cfg.dropout)
        self.n_head = cfg.n_head
        self.n_embd = cfg.n_embd

    def forward(self, x):
        B, T, C = x.shape
        q, k, v = self.qkv(x).split(self.n_embd, dim=2)
        q = q.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        k = k.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        v = v.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        y = F.scaled_dot_product_attention(
            q, k, v, is_causal=True,
            dropout_p=self.attn_drop_p if self.training else 0.0,
        )
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.resid_drop(self.proj(y))


class MLP(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.fc = nn.Linear(cfg.n_embd, 4 * cfg.n_embd, bias=cfg.bias)
        self.proj = nn.Linear(4 * cfg.n_embd, cfg.n_embd, bias=cfg.bias)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x):
        return self.drop(self.proj(F.gelu(self.fc(x))))


class Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.ln1 = nn.LayerNorm(cfg.n_embd)
        self.attn = CausalSelfAttention(cfg)
        self.ln2 = nn.LayerNorm(cfg.n_embd)
        self.mlp = MLP(cfg)

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x


class GPT(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.n_embd)
        self.pos_emb = nn.Embedding(cfg.block_size, cfg.n_embd)
        self.drop = nn.Dropout(cfg.dropout)
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layer)])
        self.ln_f = nn.LayerNorm(cfg.n_embd)
        self.head = nn.Linear(cfg.n_embd, cfg.vocab_size, bias=False)
        self.tok_emb.weight = self.head.weight  # weight tying
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)

    def forward(self, idx, targets=None):
        B, T = idx.shape
        pos = torch.arange(T, device=idx.device)
        x = self.drop(self.tok_emb(idx) + self.pos_emb(pos))
        for block in self.blocks:
            x = block(x)
        x = self.ln_f(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(
                logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1
            )
        return logits, loss

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=0.8, top_k=50):
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.cfg.block_size:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / temperature
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("inf")
            probs = F.softmax(logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, next_id), dim=1)
        return idx


# ---------------- data ----------------
def prepare_bin(tcfg: TrainConfig):
    train_bin = os.path.join(tcfg.bin_dir, "train.bin")
    val_bin = os.path.join(tcfg.bin_dir, "val.bin")
    if os.path.exists(train_bin) and os.path.exists(val_bin):
        return train_bin, val_bin

    print("tokenizing corpus -> .bin (one-time)...")
    tok = ByteLevelBPETokenizer(
        os.path.join(tcfg.tokenizer_dir, "vocab.json"),
        os.path.join(tcfg.tokenizer_dir, "merges.txt"),
    )
    with open(tcfg.data_path, "r", encoding="utf-8") as f:
        text = f.read()
    ids = np.array(tok.encode(text).ids, dtype=np.uint16)
    split = int(len(ids) * 0.9)
    ids[:split].tofile(train_bin)
    ids[split:].tofile(val_bin)
    print(f"  train: {split:,} tokens, val: {len(ids) - split:,} tokens")
    return train_bin, val_bin


def get_batch(bin_path, cfg: GPTConfig, batch_size, device):
    data = np.memmap(bin_path, dtype=np.uint16, mode="r")
    ix = np.random.randint(0, len(data) - cfg.block_size - 1, size=batch_size)
    x = torch.stack([torch.from_numpy(data[i:i + cfg.block_size].astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy(data[i + 1:i + 1 + cfg.block_size].astype(np.int64)) for i in ix])
    return x.to(device), y.to(device)


# ---------------- export: the one big fat file ----------------
def export_bundle(model: GPT, cfg: GPTConfig, tcfg: TrainConfig):
    with open(os.path.join(tcfg.tokenizer_dir, "vocab.json"), "r", encoding="utf-8") as f:
        vocab = json.load(f)
    merges = []
    with open(os.path.join(tcfg.tokenizer_dir, "merges.txt"), "r", encoding="utf-8") as f:
        for line in f.read().splitlines():
            if line.startswith("#") or not line.strip():
                continue
            parts = line.split(" ")
            if len(parts) == 2:
                merges.append((parts[0], parts[1]))

    bundle = {
        "format": "tinygenie-v1",
        "model_state_dict": model.state_dict(),
        "model_config": {
            "vocab_size": cfg.vocab_size,
            "block_size": cfg.block_size,
            "n_layer": cfg.n_layer,
            "n_head": cfg.n_head,
            "n_embd": cfg.n_embd,
            "dropout": cfg.dropout,
            "bias": cfg.bias,
        },
        "vocab": vocab,
        "merges": merges,
    }
    torch.save(bundle, tcfg.out_path)
    size_mb = os.path.getsize(tcfg.out_path) / (1024 * 1024)
    print(f"  -> {tcfg.out_path} ({size_mb:.1f}MB) [single-file: weights+config+tokenizer]")


def load_bundle(path, device):
    bundle = torch.load(path, map_location=device)
    cfg = GPTConfig()
    for k, v in bundle["model_config"].items():
        setattr(cfg, k, v)
    model = GPT(cfg).to(device)
    model.load_state_dict(bundle["model_state_dict"])
    model.eval()
    tok = ByteLevelBPETokenizer(vocab=bundle["vocab"], merges=bundle["merges"])
    return model, tok, cfg


# ---------------- train ----------------
def get_lr(it, tcfg: TrainConfig):
    if it < tcfg.warmup_iters:
        return tcfg.lr * (it + 1) / tcfg.warmup_iters
    if it > tcfg.max_iters:
        return tcfg.min_lr
    decay_ratio = (it - tcfg.warmup_iters) / (tcfg.max_iters - tcfg.warmup_iters)
    coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
    return tcfg.min_lr + coeff * (tcfg.lr - tcfg.min_lr)


@torch.no_grad()
def estimate_loss(model, cfg, tcfg, train_bin, val_bin):
    model.eval()
    out = {}
    for name, path in [("train", train_bin), ("val", val_bin)]:
        losses = torch.zeros(tcfg.eval_iters)
        for k in range(tcfg.eval_iters):
            x, y = get_batch(path, cfg, tcfg.batch_size, tcfg.device)
            _, loss = model(x, y)
            losses[k] = loss.item()
        out[name] = losses.mean().item()
    model.train()
    return out


def train():
    cfg = GPTConfig()
    tcfg = TrainConfig()
    print(f"device: {tcfg.device}")

    train_bin, val_bin = prepare_bin(tcfg)

    model = GPT(cfg).to(tcfg.device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"model: {n_params / 1e6:.1f}M params")

    optimizer = torch.optim.AdamW(model.parameters(), lr=tcfg.lr, weight_decay=tcfg.weight_decay)
    scaler = torch.amp.GradScaler(enabled=tcfg.amp)

    t0 = time.time()
    for it in range(tcfg.max_iters):
        lr = get_lr(it, tcfg)
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        for _ in range(tcfg.grad_accum_steps):
            x, y = get_batch(train_bin, cfg, tcfg.batch_size, tcfg.device)
            with torch.amp.autocast(device_type="cuda", enabled=tcfg.amp):
                _, loss = model(x, y)
                loss = loss / tcfg.grad_accum_steps
            scaler.scale(loss).backward()

        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), tcfg.grad_clip)
        scaler.step(optimizer)
        scaler.update()

        if it % tcfg.eval_interval == 0 or it == tcfg.max_iters - 1:
            losses = estimate_loss(model, cfg, tcfg, train_bin, val_bin)
            dt = time.time() - t0
            print(f"iter {it}: train {losses['train']:.4f}, val {losses['val']:.4f}, lr {lr:.2e}, {dt:.0f}s")
            export_bundle(model, cfg, tcfg)  # overwrite the one file each checkpoint

    export_bundle(model, cfg, tcfg)
    print("training done.")


# ---------------- inference ----------------
def generate(prompt, max_new_tokens=200):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, tok, cfg = load_bundle(TrainConfig.out_path, device)
    ids = tok.encode(prompt).ids
    idx = torch.tensor([ids], dtype=torch.long, device=device)
    out = model.generate(idx, max_new_tokens=max_new_tokens)[0].tolist()
    print(tok.decode(out))


def chat():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, tok, cfg = load_bundle(TrainConfig.out_path, device)
    print(f"TinyGenie loaded from {TrainConfig.out_path}. Ctrl+C to quit.")
    while True:
        try:
            prompt = input("> ")
        except (KeyboardInterrupt, EOFError):
            break
        ids = tok.encode(prompt).ids
        idx = torch.tensor([ids], dtype=torch.long, device=device)
        out = model.generate(idx, max_new_tokens=200)[0].tolist()
        print(tok.decode(out))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python tinygenie.py [train|chat|generate \"prompt\"]")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "train":
        train()
    elif cmd == "chat":
        chat()
    elif cmd == "generate":
        generate(sys.argv[2] if len(sys.argv) > 2 else "")
    else:
        print(f"unknown command: {cmd}")
