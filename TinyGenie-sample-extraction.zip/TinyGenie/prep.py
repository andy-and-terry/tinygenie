"""
TinyGenie prep — run once.
Downloads EN + ZH-Hans base corpus, merges in your data/custom/*.txt
(Singlish, slang, code-switch like "你好 I am here to 睡觉"), trains the
byte-level BPE tokenizer on the result.

Usage: python prep.py
"""
import os
import lzma
import requests
from tokenizers import ByteLevelBPETokenizer

VOCAB_SIZE = 32000
CC100_URLS = {
    "en": "http://data.statmt.org/cc-100/en.txt.xz",
    "zh-Hans": "http://data.statmt.org/cc-100/zh-Hans.txt.xz",
}
CAP_BYTES_PER_LANG = 30 * 1024 * 1024
CUSTOM_REPEAT = 20

DATA_DIR = "data"
CUSTOM_DIR = os.path.join(DATA_DIR, "custom")
COMBINED_PATH = os.path.join(DATA_DIR, "combined.txt")
TOKENIZER_DIR = "tokenizer"


def download_capped(url, cap_bytes):
    print(f"  downloading {url} (cap {cap_bytes // (1024*1024)}MB)...")
    decompressor = lzma.LZMADecompressor()
    collected = bytearray()
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        for chunk in r.iter_content(chunk_size=1 << 16):
            if not chunk:
                continue
            try:
                collected.extend(decompressor.decompress(chunk))
            except lzma.LZMAError:
                break
            if len(collected) >= cap_bytes:
                break
    text = collected[:cap_bytes].decode("utf-8", errors="ignore")
    last_nl = text.rfind("\n")
    return text[:last_nl] if last_nl != -1 else text


def load_custom_texts():
    os.makedirs(CUSTOM_DIR, exist_ok=True)
    parts = []
    for fname in sorted(os.listdir(CUSTOM_DIR)):
        if fname.endswith((".txt", ".md")):
            path = os.path.join(CUSTOM_DIR, fname)
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                parts.append(f.read())
            print(f"  loaded custom file: {fname} ({os.path.getsize(path)} bytes)")
    if not parts:
        print(f"  (no files in {CUSTOM_DIR}/ — drop .txt files there and rerun for Singlish/slang flavor)")
        return ""
    return "\n".join(parts)


def build_corpus():
    os.makedirs(DATA_DIR, exist_ok=True)
    chunks = []

    print("[1/3] base corpora (EN + ZH-Hans)")
    for lang, url in CC100_URLS.items():
        try:
            chunks.append(download_capped(url, CAP_BYTES_PER_LANG))
        except Exception as e:
            print(f"  WARNING: failed to fetch {lang}: {e}")

    print("[2/3] custom texts (Singlish / slang / code-switch)")
    custom = load_custom_texts()
    if custom:
        chunks.append((custom + "\n") * CUSTOM_REPEAT)

    combined = "\n".join(chunks)
    with open(COMBINED_PATH, "w", encoding="utf-8") as f:
        f.write(combined)
    print(f"  -> {COMBINED_PATH} ({len(combined) / (1024*1024):.1f}MB)")


def train_tokenizer():
    print("[3/3] training tokenizer")
    os.makedirs(TOKENIZER_DIR, exist_ok=True)
    tok = ByteLevelBPETokenizer()
    tok.train(
        files=[COMBINED_PATH],
        vocab_size=VOCAB_SIZE,
        min_frequency=2,
        special_tokens=["<pad>", "<bos>", "<eos>", "<unk>"],
    )
    tok.save_model(TOKENIZER_DIR)
    print(f"  -> {TOKENIZER_DIR}/")


if __name__ == "__main__":
    build_corpus()
    train_tokenizer()
    print("\ndone. next: python tinygenie.py train")
